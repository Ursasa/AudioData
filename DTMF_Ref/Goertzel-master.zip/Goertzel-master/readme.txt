Todo:

Look to replace floats for quicker running.
More full featured DTMF tone detection example.